TOMBOLA CAZZARA - SUONI REGIA
Caricare tutti questi file nella cartella tombola-cazzara/public/sounds/

Associazione prevista dei pulsanti:
1 - Alleluja
2 - Applausi
3 - Deleterio
4 - Numero ingrato
5 - Radetzky March
6 - Sigla Cazzara lunga
7 - Sigla Cazzara breve
8 - Vaffa
9 - Warning
